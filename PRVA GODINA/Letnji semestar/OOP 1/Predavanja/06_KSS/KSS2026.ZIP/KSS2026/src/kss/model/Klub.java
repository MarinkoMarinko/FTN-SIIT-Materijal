package kss.model;

public class Klub {
	private int sifra;
	private String naziv;
	
	public Klub() {
		
	}
	
	public Klub(int sifra, String naziv) {
		this();
		this.sifra = sifra;
		this.naziv = naziv;
	}

	public int getSifra() {
		return sifra;
	}
	public void setSifra(int sifra) {
		this.sifra = sifra;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public static Klub parseKlub(String s) throws ParseException {
		String[] tokens = s.split(";");
		if (tokens.length == 2) {
			try {
				int sifra = Integer.parseInt(tokens[0].trim());
				Klub k = new Klub(sifra, tokens[1].trim());
				return k;
			} catch (NumberFormatException ex) {
				throw new ParseException("Ne valja format šifre:" + tokens[0].trim() + " u redu: " + s);
			}
		}
		throw new ParseException("Ne valja format reda: " + s);
	}
	
	@Override
	public String toString() {
		return "Klub [sifra=" + sifra + ", naziv=" + naziv + "]";
	}

	public Object toCell(int columnIndex) {
		switch(columnIndex) {
			case 0: return sifra;
			case 1: return naziv;
		}
		return null;
	}
}
