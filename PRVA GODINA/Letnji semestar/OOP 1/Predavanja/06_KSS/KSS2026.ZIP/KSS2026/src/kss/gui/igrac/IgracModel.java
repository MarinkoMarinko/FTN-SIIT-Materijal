package kss.gui.igrac;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import kss.manager.IgracManager;
import kss.model.Igrac;
import kss.model.Klub;

public class IgracModel extends AbstractTableModel {

	private IgracManager im;
	
	String[] kolone = new String[] {"Šifra", "Ime", "Prezime", "Klub"};
	List<Igrac> vrste = new ArrayList<Igrac>();
	Igrac dummy = new Igrac(-1, "", "", new Klub(-1, ""));

	public IgracModel(IgracManager im) {
		this.im = im;
		for(Igrac i : im.igraci.values()) {
			vrste.add(i);
		}
	}
	
	@Override
	public int getRowCount() {
		return vrste.size();
	}

	@Override
	public int getColumnCount() {
		return kolone.length;
	}

	@Override
	public String getColumnName(int columnIndex) {
		return kolone[columnIndex];
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return dummy.toCell(columnIndex).getClass();
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Igrac i = vrste.get(rowIndex);
		return i.toCell(columnIndex);
	}

//	@Override
//	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
//		// TODO Auto-generated method stub
//
//	}

}
