package kss.gui.klub;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import kss.manager.KlubManager;
import kss.model.Klub;

public class KlubModel extends AbstractTableModel {

	private static final long serialVersionUID = -2488006504252002649L;
	private KlubManager km;
	
	private String[] kolone = new String[] {"Šifra", "Naziv"};
	private List<Klub> vrste = new ArrayList<Klub>();
	private Klub dummy = new Klub(-1, "");

	public KlubModel(KlubManager km) {
		this.km = km;
		for(Klub k : km.klubovi.values()) {
			vrste.add(k);
		}
	}
	
	@Override
	public int getRowCount() {
		return vrste.size();
	}

	@Override
	public int getColumnCount() {
		return kolone.length;
	}

	@Override
	public String getColumnName(int columnIndex) {
		return kolone[columnIndex];
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return dummy.toCell(columnIndex).getClass();
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Klub k = vrste.get(rowIndex);
		return k.toCell(columnIndex);
	}

//	@Override
//	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
//		// TODO Auto-generated method stub
//
//	}

}
