package kss.model;

public class ParseException extends Exception {
	private static final long serialVersionUID = 7368451699000987845L;

	public ParseException(String msg) {
		super(msg);
	}
}
