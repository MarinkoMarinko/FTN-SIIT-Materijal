package kss.manager;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import kss.model.Klub;
import kss.model.ParseException;

public class KlubManager {
	
	public Map<Integer, Klub> klubovi = new HashMap<Integer, Klub>();
	
	public KlubManager(String fileName) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String s;
			while((s = in.readLine()) != null) {
				s = s.trim();
				if ((s.length()==0) || (s.startsWith("#"))) {
					continue;
				}
				try {
					Klub k = Klub.parseKlub(s);
					klubovi.put(k.getSifra(), k);
				} catch (ParseException e) {
					//e.printStackTrace();
					System.err.println(e.getMessage());
				}
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
