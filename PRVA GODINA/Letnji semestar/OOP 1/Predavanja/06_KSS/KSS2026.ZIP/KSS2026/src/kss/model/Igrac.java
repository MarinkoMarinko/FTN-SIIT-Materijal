package kss.model;

import kss.manager.KlubManager;

public class Igrac {
	private int sifra;
	private String ime;
	private String prezime;
	private Klub klub;
	
	public Igrac() {
		
	}
	
	public Igrac(int sifra, String ime, String prezime, Klub klub) {
		this();
		this.sifra = sifra;
		this.ime = ime;
		this.prezime = prezime;
		this.klub = klub;
	}

	public int getSifra() {
		return sifra;
	}
	public void setSifra(int sifra) {
		this.sifra = sifra;
	}
	public String getIme() {
		return ime;
	}
	public void setIme(String ime) {
		this.ime = ime;
	}
	public String getPrezime() {
		return prezime;
	}
	public void setPrezime(String prezime) {
		this.prezime = prezime;
	}
	public Klub getKlub() {
		return klub;
	}
	public void setKlub(Klub klub) {
		this.klub = klub;
	}

	public static Igrac parseIgrac(String s, KlubManager km) throws ParseException {
		String[] tokens = s.split(";");
		if (tokens.length == 4) {
			try {
				int sifra = Integer.parseInt(tokens[0].trim());
				String ime = tokens[1].trim();
				String prezime = tokens[2].trim();
				int klubSifra = Integer.parseInt(tokens[3].trim());
				Klub k = km.klubovi.get(klubSifra);
				if (k != null) {
					Igrac i = new Igrac(sifra, ime, prezime, k);
					return i;
				} 
				throw new ParseException("Nisam našao klub sa šifrom: " + klubSifra);
			} catch(NumberFormatException ex) {
				throw new ParseException("Ne valja format šifre:" + ex.getMessage() + " u redu: " + s);
			}
		}
		throw new ParseException("Ne valja format reda: " + s);
	}
	
	@Override
	public String toString() {
		return "Igrac [sifra=" + sifra + ", ime=" + ime + ", prezime=" + prezime + ", klub=" + klub + "]";
	}

	public Object toCell(int columnIndex) {
		switch(columnIndex) {
			case 0: return sifra;
			case 1: return ime;
			case 2: return prezime;
			case 3: return klub.getNaziv();
		}
		return null;
	}
}
