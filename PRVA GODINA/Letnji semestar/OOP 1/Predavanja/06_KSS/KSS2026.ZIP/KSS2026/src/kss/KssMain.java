package kss;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

import kss.gui.igrac.IgraciDialog;
import kss.gui.klub.KluboviDialog;
import kss.manager.IgracManager;
import kss.manager.KlubManager;

public class KssMain extends JFrame {
	private static final long serialVersionUID = -7296402190921762782L;

	KlubManager km = new KlubManager("klubovi.txt");
	KluboviDialog klubovi = new KluboviDialog(this, km);
	
	IgracManager im = new IgracManager("igraci.txt", km);
	IgraciDialog igraci = new IgraciDialog(this, im);
	
	public KssMain() {
		
		System.out.println(km.klubovi);
		System.out.println(im.igraci);
		
		setTitle("Košarkaški savez Srbije");
		setSize(800, 600);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		FlowLayout fl = new FlowLayout();
		setLayout(fl);
		
		JButton btnKlubovi = new JButton("Klubovi");
		getContentPane().add(btnKlubovi);
		btnKlubovi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				klubovi.setVisible(true);
			}
		});
		
		JButton btnIgraci = new JButton("Igrači");
		getContentPane().add(btnIgraci);
		btnIgraci.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				igraci.setVisible(true);
			}
		});
		
		JButton btnUgasi = new JButton("Ugasi");
		getContentPane().add(btnUgasi);
		btnUgasi.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		setVisible(true);
	}
	public static void main(String[] args) {
		new KssMain();
	}

}
