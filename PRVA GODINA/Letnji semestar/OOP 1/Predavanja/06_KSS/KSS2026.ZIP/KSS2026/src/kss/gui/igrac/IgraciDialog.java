package kss.gui.igrac;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import kss.manager.IgracManager;

public class IgraciDialog extends JDialog {

	private static final long serialVersionUID = 6530725197217339507L;
	
	public IgraciDialog(JFrame parent, IgracManager im) {
		super(parent, false);
		setTitle("Igrači");
		setSize(800, 600);
		
		BorderLayout bl = new BorderLayout();
		setLayout(bl);
		
		JTable tabela = new JTable(new IgracModel(im));
		JScrollPane sp = new JScrollPane(tabela);
		getContentPane().add(sp, BorderLayout.CENTER);
		
		JPanel dole = new JPanel();
		JButton btnZatvori = new JButton("Zatvori");
		btnZatvori.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		dole.add(btnZatvori);
		getContentPane().add(dole, BorderLayout.SOUTH);
		
	}

}
