package kss.manager;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import kss.model.Igrac;
import kss.model.ParseException;

public class IgracManager {
	
	public Map<Integer, Igrac> igraci = new HashMap<Integer, Igrac>();
	
	public IgracManager(String fileName, KlubManager km) {
		try {
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String s;
			while ((s = in.readLine()) != null) {
				s = s.trim();
				if ((s.length() == 0) || (s.startsWith("#"))) {
					continue;
				}
				try {
					Igrac i = Igrac.parseIgrac(s, km);
					igraci.put(i.getSifra(), i);
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
